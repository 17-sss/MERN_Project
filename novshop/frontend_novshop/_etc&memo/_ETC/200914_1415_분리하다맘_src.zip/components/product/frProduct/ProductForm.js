import React from 'react';
import {ProductItemContainer, ProductItemRow} from './StyledProductForm';

const ProductForm = (props) => {
    const {children} = props;

    return (
        <ProductItemContainer>
            <ProductItemRow className="row-cols-4">
                {children}
            </ProductItemRow>
        </ProductItemContainer>
    );
};

export default ProductForm;