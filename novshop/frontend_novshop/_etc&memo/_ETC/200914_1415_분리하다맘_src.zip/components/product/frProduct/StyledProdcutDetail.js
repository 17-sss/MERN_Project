import styled, {css} from 'styled-components';
import { getSize } from "../../../lib/utility/customFunc";

const calcImageRatio = (AnNum, AstrType) => {      
    const strType = (AstrType !== ("width" && "height") ? "err" : AstrType);
    const nDiv10 = Number(getSize(1.5, strType, false, true)) / 10;
    return (nDiv10 * AnNum) + "px";
};


// 상품 상세 :: [공통] START ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
// ========================================================================================
// ************* 상품 상세 -  Wrapper *************
// ========================================================================================
const ProductDetailWrapper = styled.div`
    margin: 0 auto;

    ${(props) => {
        const {mode} = props;        
        const caseMode = (mode !== ("detail" && "additional") ? "detail" : mode);
        
        switch (caseMode) {
            case "detail":{
                return css`
                    width: ${getSize(1.5)};
                `;
            }           
            case "additional": {
                return css`
                    width: ${getSize(1.4)};
                `;
            }
        
            default:    
                break;
        }
    }}
`;
// ---------------------------------------------------/


// ========================================================================================
// ************* 상품 상세 - 다용도 wrapper *************
// ========================================================================================
const ProductMultiWrapper = styled.div`
    ${props => {
        const {mode, height, width} = props;        
        const caseMode = (mode !== ("detail" && "additional") ? "detail" : mode);        
    
        switch (caseMode) {        
            case "detail": {
                return css`
                    height: ${() => height || calcImageRatio(5, "width")};
                    width: ${() => width || "50%"};    
                    display: inline-block;                                              
                `;
            }
            case "additional": {
                return css`
                `;
            }        
            default:    
                break;
        }
    }}
`;
// ---------------------------------------------------/
// 상품 상세 :: [공통] END ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒


export {ProductDetailWrapper, ProductMultiWrapper};