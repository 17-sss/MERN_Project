import React from 'react';
import ProductDetail from "./frProduct/ProductDetail";

const ProductDetailTemplate = (props) => {
    return (
        <ProductDetail {...props}/>        
    );
};

export default ProductDetailTemplate;