import React from 'react';
import {FooterWrapper} from './StyledFooter';

const Footer = () => {
    return (
        <>
            <FooterWrapper>
                <h1> THIS IS FOOTER</h1>
            </FooterWrapper>
        </>
    )
};

export default Footer;