import React, { useRef, useEffect, useState } from 'react';
import PropTypes from 'prop-types';

import {
    StyledItem,
    ImageWrapper,
    ProductWrapper,
    ProductColorWrapper,
    ProductColor,
    ProductNameLink,
    ProductPriceUl,
    ProductPriceLi,
} from './StyledProductItem';


import { ClearEx, CustomLink } from '../../common/StyleUtilModels';

const ProductItem = (props) => {
    // ** useHooks **
    const [colHeight, setColHeight] = useState(0);
    const colRef = useRef(null);

    const [imgHeight, setImgHeight] = useState(0);
    const imgRef = useRef(null);
    const imgOnload = () => {
        return setImgHeight(imgRef.current.clientHeight);
    };

    useEffect(() => {
        setColHeight(colRef.current.clientHeight);
    }, [colHeight, imgHeight]);

    const imageTagHeight = () => {
        if (colHeight === 0 || imgHeight === 0) {
            return;
        }

        if (colHeight * 0.7 < imgHeight) return 'auto';
        else return colHeight * 0.7;
    };

    // ** props 변수화 **
    const {
        itemImage, // 이미지: 이미지가 있는 위치
        itemName, // 상품명
        itemLink, // 상품링크
        itemSize, // 상품사이즈 정보
        itemColors, // 상품컬러 정보
        price, // 상품가격 - 일반가
        sale, // 상품가격 - 세일가
        description, // 상품 부가설명
    } = props;

    // ** render **
    return (
        <StyledItem ref={colRef}>
            {/* 이미지 START */}
            <ImageWrapper>
                <CustomLink to={itemLink}>
                    <img
                        ref={imgRef}
                        onLoad={imgOnload}
                        src={itemImage}
                        alt={itemName}
                        width="100%"
                        height={imageTagHeight()}
                    />
                </CustomLink>
            </ImageWrapper>
            {/* 이미지 END */}

            <ClearEx />

            {/* 상품 START */}
            <ProductWrapper>
                {/* 색상 */}
                <ProductColorWrapper>
                    {itemColors.map((value, i) => {
                        return <ProductColor key={i} color={value} />;
                    })}
                </ProductColorWrapper>

                <ClearEx style={{ padding: '2px 0' }} />

                {/* 상품명 & 사이즈 정보 */}
                <ProductNameLink to={itemLink}>
                    {itemName}

                    <span className="sizeInfo">
                        {itemSize.map((value, i) => {
                            const thisLen = itemSize.length;
                            if (i === thisLen - 1) {
                                return value + ']';
                            } else if (i === 0) {
                                return '[' + value + ', ';
                            } else {
                                return value + ',';
                            }
                        })}
                    </span>
                </ProductNameLink>

                {/* 상품가격 */}
                <ProductPriceUl mode={1}>
                    {/* [1] 일반  */}
                    <ProductPriceLi className="price" price={price} sale={sale}>
                        {price}원
                    </ProductPriceLi>

                    {/* [2] 세일 */}
                    <ProductPriceLi className="sale" sale={sale}>
                        {sale}원
                    </ProductPriceLi>
                </ProductPriceUl>

                <ProductPriceUl mode={2}>
                    {/* [3] 부가설명 */}
                    <ProductPriceLi
                        className="description"
                        description={description}
                    >
                        {description}
                    </ProductPriceLi>
                </ProductPriceUl>
            </ProductWrapper>
            {/* 상품 END */}
        </StyledItem>
    );
};

// ** props 기본값 지정 **
ProductItem.defaultProps = {
    itemImage: '',
    itemName: '',
    itemLink: '',
    itemSize: [],
    itemColors: [],
    price: 0,
    sale: 0,
    description: '',
};

// ** props 기본 타입 지정 **
ProductItem.propTypes = {
    itemImage: PropTypes.string,
    itemName: PropTypes.string,
    itemLink: PropTypes.string,
    itemSize: PropTypes.array,
    itemColors: PropTypes.array,
    price: PropTypes.number,
    sale: PropTypes.number,
    description: PropTypes.string,
};

export default ProductItem;
