import styled, { css } from 'styled-components';
import { Col } from 'react-bootstrap';
import { getSize } from '../../../lib/utility/customFunc';
import { cssDisplayNone, cssStrike } from '../../common/StyleUtilCSS';
import { CustomLink } from '../../common/StyleUtilModels';


// ========================================================================================
// ************* Col(최상위) 틀 *************
// ========================================================================================
const StyledItem = styled(Col)`
    height: ${getSize(1.6, 'height')};
    /* border: 1px solid black; */
    padding: 15px;
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품이미지 Wrapper *************
// ========================================================================================
const ImageWrapper = styled.div`
    text-align: center; 
    margin: 5px 0;
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 Wrapper *************
// ========================================================================================
const ProductWrapper = styled.div`
    width: 100%;
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 - 색상 Wrapper *************
// ========================================================================================
const ProductColorWrapper = styled.div`
    width: 100%;
    margin: 10px 0;
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 - 색상 *************
// ========================================================================================
const ProductColor = styled.span`
    width: 20px;
    height: 4px;
    margin-right: 2px;
    float: left;
    box-sizing: border-box;
    border: 1px solid #e3e3e5;
    font-size: 0;
    line-height: 0;

    background-color: ${(props) =>
        props.color === undefined ? 'black' : props.color};
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 - 상품명, 사이즈 *************
// ========================================================================================
const ProductNameLink = styled(CustomLink)`
    margin: 0;  
    padding: 0;

    font-weight: bold;
    font-size: 13px;
    color: black;

    &:focus,
    &:hover,
    &:visited,
    &:link,
    &:active {
        color: black;
    }

    .sizeInfo {
        padding-left: 4px;
        font-size: 11px;
        color: #666666;
        font-weight: normal;
    }
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 - 가격 & 부가설명 ul *************
// ========================================================================================
const ProductPriceUl = styled.ul`
    ${(props) => {      
        switch (props.mode) {
            // mode 1 : 가격 관련
            case 1: {
                return css`
                    padding-bottom: 22px;
                    display: block;
                    height: 16px;
                    line-height: 16px;
                    font-size: 12px;
                    border-bottom: 1px solid #e6e6e6;
                `;
            }
            // mode 2: 부가설명
            case 2: {
                return css`
                    line-height: 1.5em;
                `;
            }

            default:
                break;
        }
    }}
`;
// ---------------------------------------------------/

// ========================================================================================
// ************* 상품 - 가격 & 부가설명 li *************
// ========================================================================================
const cssNormalPrice = css`
    display: inline-block;                        
    color: black;
    font-size: 10pt;
    padding-right: 10px;
`;

const ProductPriceLi = styled.li`
    /* 일반 가격 */
    &.price {
        ${(props) => {
            const {sale, price} = props;

            if (!sale) {
                if (price)  return cssNormalPrice; 
                else        return [cssDisplayNone, cssStrike];
            } else {
                if (price) {
                    return css`
                        ${cssNormalPrice};
                        color: #666666;
                        ${cssStrike};
                    `;
                } else {
                    return [cssDisplayNone, cssStrike]; 
                }                
            }
        }}
    }

    /* 세일 */
    &.sale {
        ${(props) => {
            const {sale} = props;

            if (!sale)  return [cssDisplayNone, cssStrike];
            else        return cssNormalPrice;            
        }}
    }

    /* 부가설명 */
    &.description {        
        ${(props) => {
            const {description} = props;

            if (!description) {
                return [cssDisplayNone, cssStrike]
            } else {
                return css`
                    text-align: left;
                    position: relative;
                    /* margin: 4px auto 0px; 상 - 좌우 - 하 */
                    margin: 0 auto;
                    color: #666666;                    
                    font-size: 11.5px;
                    line-height: 22px;  /* 이거쓰면 라인(글)이 밑으로 내려감, 굳이 마진 패딩안써도됨. */
                `;
            }
        }}
    }
`;
// ---------------------------------------------------/


export {StyledItem, ImageWrapper, ProductWrapper, ProductColorWrapper, ProductColor, ProductNameLink, ProductPriceUl, ProductPriceLi};