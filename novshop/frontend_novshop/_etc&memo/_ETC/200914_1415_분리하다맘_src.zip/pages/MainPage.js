import React from 'react';
import MainTemplate from '../components/main/MainTemplate';

const MainPage = () => {
    return (
        <MainTemplate/>
    );
};

export default MainPage;