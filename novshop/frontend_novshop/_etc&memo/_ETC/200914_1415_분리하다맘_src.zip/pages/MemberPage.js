import React from 'react';

const MemberPage = () => {
    return (
        <div>
            This is MemberPage.
        </div>
    )
};

export default MemberPage;