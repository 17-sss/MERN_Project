import React from 'react';
import { StyledHr, ClearEx } from "../../common/StyleUtilModels";
import {ProductDetailWrapper, ProductMultiWrapper} from './StyledProdcutDetail';

const ProductDetail = (props) => {
    const {itemImage, itemName} = props;
    console.log(props);

    return (
        <>
            {/* 상품 상세 :: 구매, 이미지, 가격 등 */}
            <ProductDetailWrapper>
                <ProductMultiWrapper>
                    <img                                            
                        src={itemImage}
                        alt={itemName}
                        width="100%"
                        height={"auto"}
                        style={{
                            margin: "10px",                        
                        }}
                    />
                </ProductMultiWrapper>
                
                <ProductMultiWrapper>
                    123
                </ProductMultiWrapper>
            </ProductDetailWrapper>

            <ClearEx />
            <StyledHr/>

            {/* 상품 상세 :: 추가정보(제품 상세정보) */}
            <ProductDetailWrapper mode = {"additional"}>
                Test2
            </ProductDetailWrapper>
        </>
    );
};

export default ProductDetail;